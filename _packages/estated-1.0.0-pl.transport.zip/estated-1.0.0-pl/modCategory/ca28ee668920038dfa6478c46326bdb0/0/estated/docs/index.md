# MODX-Estated

> A MODX Extra for www.estated.com real estate data service

##Features:
1. Estated Address Look up via PHP Snippet


## Dependencies:
1. www.Estated.com API Key
