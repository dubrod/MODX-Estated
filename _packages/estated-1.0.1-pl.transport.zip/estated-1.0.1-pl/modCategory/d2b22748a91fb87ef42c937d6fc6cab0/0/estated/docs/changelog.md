#Estated 1.0.1
- Template Variable option to exclude resource from lookup so you don't burn up API queries.

#Estated 1.0.0
- Installer Ready
