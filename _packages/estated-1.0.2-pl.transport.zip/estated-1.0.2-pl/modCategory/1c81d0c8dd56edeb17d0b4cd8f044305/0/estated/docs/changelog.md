#Estated 1.0.2
- 2 Column List for all Parameters
- Resource to Refresh data

#Estated 1.0.1
- 20+ Template Variables and API Snippet

#Estated 1.0.0
- Installer Ready
