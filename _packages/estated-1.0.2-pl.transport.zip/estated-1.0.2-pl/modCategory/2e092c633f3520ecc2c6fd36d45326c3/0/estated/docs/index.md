# MODX-Estated

> A MODX Extra for www.estated.com real estate data service

##Usage:
1. Install package
2. Go to System Settings; Update API Key and Templated ID used for Individual Listings
3. Go to Template used for Individual Listings and assign the `Estated` TVs
4. Create a resource for your listing. Info Required: Street, City, State, Zip
5. Go to `/estated-lookup`
6. Clear Cache to recache resources if necessary.
